import { Router, Request, Response, NextFunction } from 'express';
import { query, run, get } from '../db';
import { Todo, CreateTodoBody, UpdateTodoBody } from '../types/todo';

const router = Router();

// GET /api/todos?status=&priority=
router.get('/', (req: Request, res: Response, next: NextFunction) => {
  try {
    const { status, priority } = req.query as { status?: string; priority?: string };
    const conditions: string[] = [];
    const values: unknown[] = [];

    if (status) { conditions.push(`status = ?`); values.push(status); }
    if (priority) { conditions.push(`priority = ?`); values.push(priority); }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const todos = query<Todo>(`SELECT * FROM todos ${where} ORDER BY created_at DESC`, values);
    res.json(todos);
  } catch (err) {
    next(err);
  }
});

// GET /api/todos/:id
router.get('/:id', (req: Request, res: Response, next: NextFunction) => {
  try {
    const todo = get<Todo>('SELECT * FROM todos WHERE id = ?', [req.params.id]);
    if (!todo) { res.status(404).json({ error: 'Todo not found' }); return; }
    res.json(todo);
  } catch (err) {
    next(err);
  }
});

// POST /api/todos
router.post('/', (req: Request, res: Response, next: NextFunction) => {
  try {
    const body = req.body as CreateTodoBody;
    if (!body.title?.trim()) { res.status(400).json({ error: 'title is required' }); return; }

    const result = run(
      `INSERT INTO todos (title, description, priority, status, due_date, category, is_important)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        body.title.trim(),
        body.description ?? null,
        body.priority ?? 'medium',
        body.status ?? 'pending',
        body.due_date ?? null,
        body.category ?? null,
        body.is_important ? 1 : 0,
      ]
    );
    const created = get<Todo>('SELECT * FROM todos WHERE id = ?', [result.lastInsertRowid]);
    res.status(201).json(created);
  } catch (err) {
    next(err);
  }
});

// PUT /api/todos/:id
router.put('/:id', (req: Request, res: Response, next: NextFunction) => {
  try {
    const body = req.body as UpdateTodoBody;
    const fields: string[] = [];
    const values: unknown[] = [];

    if (body.title !== undefined) { fields.push('title = ?'); values.push(body.title.trim()); }
    if (body.description !== undefined) { fields.push('description = ?'); values.push(body.description); }
    if (body.priority !== undefined) { fields.push('priority = ?'); values.push(body.priority); }
    if (body.status !== undefined) { fields.push('status = ?'); values.push(body.status); }
    if (body.due_date !== undefined) { fields.push('due_date = ?'); values.push(body.due_date); }
    if (body.category !== undefined) { fields.push('category = ?'); values.push(body.category); }
    if (body.is_important !== undefined) { fields.push('is_important = ?'); values.push(body.is_important ? 1 : 0); }

    if (fields.length === 0) { res.status(400).json({ error: 'No fields to update' }); return; }

    values.push(req.params.id);
    const result = run(`UPDATE todos SET ${fields.join(', ')} WHERE id = ?`, values);

    if (result.changes === 0) { res.status(404).json({ error: 'Todo not found' }); return; }
    const updated = get<Todo>('SELECT * FROM todos WHERE id = ?', [req.params.id]);
    res.json(updated);
  } catch (err) {
    next(err);
  }
});

// DELETE /api/todos/:id
router.delete('/:id', (req: Request, res: Response, next: NextFunction) => {
  try {
    const result = run('DELETE FROM todos WHERE id = ?', [req.params.id]);
    if (result.changes === 0) { res.status(404).json({ error: 'Todo not found' }); return; }
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

export default router;
