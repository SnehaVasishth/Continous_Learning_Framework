export type Priority = 'high' | 'medium' | 'low';
export type TodoStatus = 'pending' | 'in-progress' | 'completed';

export interface Todo {
  id: number;
  title: string;
  description: string | null;
  priority: Priority;
  status: TodoStatus;
  due_date: string | null;
  category: string | null;
  is_important: number;
  created_at: string;
  updated_at: string;
}

export interface CreateTodoBody {
  title: string;
  description?: string;
  priority?: Priority;
  status?: TodoStatus;
  due_date?: string;
  category?: string;
  is_important?: boolean;
}

export type UpdateTodoBody = Partial<CreateTodoBody>;
