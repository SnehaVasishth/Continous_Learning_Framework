#!/bin/sh
until [ -f /tmp/todo-backend-port ]; do sleep 0.3; done
VITE_BACKEND_PORT=$(cat /tmp/todo-backend-port)
export VITE_BACKEND_PORT
npm run dev
