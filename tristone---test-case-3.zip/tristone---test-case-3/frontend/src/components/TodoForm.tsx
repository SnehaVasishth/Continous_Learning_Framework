import { useState, useEffect, FormEvent } from 'react';
import { Todo, CreateTodoPayload, Priority, TodoStatus } from '../types/todo';

interface Props {
  initial?: Todo | null;
  onSubmit: (payload: CreateTodoPayload) => Promise<void>;
  onCancel: () => void;
}

const emptyForm = (): CreateTodoPayload => ({
  title: '',
  description: '',
  priority: 'medium',
  status: 'pending',
  due_date: '',
  category: '',
});

export function TodoForm({ initial, onSubmit, onCancel }: Props) {
  const [form, setForm] = useState<CreateTodoPayload>(emptyForm());
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (initial) {
      setForm({
        title: initial.title,
        description: initial.description ?? '',
        priority: initial.priority,
        status: initial.status,
        due_date: initial.due_date ?? '',
        category: initial.category ?? '',
      });
    } else {
      setForm(emptyForm());
    }
  }, [initial]);

  const set = (key: keyof CreateTodoPayload, value: string) =>
    setForm(prev => ({ ...prev, [key]: value }));

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!form.title.trim()) { setError('Title is required'); return; }
    setError('');
    setSubmitting(true);
    try {
      await onSubmit({
        ...form,
        description: form.description || undefined,
        due_date: form.due_date || undefined,
        category: form.category || undefined,
      });
      setForm(emptyForm());
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onCancel}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <h2>{initial ? 'Edit Todo' : 'New Todo'}</h2>
        {error && <p className="error-text">{error}</p>}
        <form onSubmit={handleSubmit} className="todo-form">
          <label>
            Title *
            <input
              type="text"
              value={form.title}
              onChange={e => set('title', e.target.value)}
              placeholder="What needs to be done?"
              autoFocus
            />
          </label>

          <label>
            Description
            <textarea
              value={form.description}
              onChange={e => set('description', e.target.value)}
              placeholder="Optional details…"
              rows={3}
            />
          </label>

          <div className="form-row">
            <label>
              Priority
              <select value={form.priority} onChange={e => set('priority', e.target.value as Priority)}>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
            </label>

            <label>
              Status
              <select value={form.status} onChange={e => set('status', e.target.value as TodoStatus)}>
                <option value="pending">Pending</option>
                <option value="in-progress">In Progress</option>
                <option value="completed">Completed</option>
              </select>
            </label>
          </div>

          <div className="form-row">
            <label>
              Due Date
              <input type="date" value={form.due_date} onChange={e => set('due_date', e.target.value)} />
            </label>

            <label>
              Category
              <input
                type="text"
                value={form.category}
                onChange={e => set('category', e.target.value)}
                placeholder="e.g. work, personal"
              />
            </label>
          </div>

          <div className="form-actions">
            <button type="button" className="btn-secondary" onClick={onCancel}>Cancel</button>
            <button type="submit" className="btn-primary" disabled={submitting}>
              {submitting ? 'Saving…' : initial ? 'Save Changes' : 'Add Todo'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
