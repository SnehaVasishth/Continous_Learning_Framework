import { TodoFilters, TodoStatus, Priority } from '../types/todo';

interface Props {
  filters: TodoFilters;
  onChange: (f: TodoFilters) => void;
}

export function FilterBar({ filters, onChange }: Props) {
  return (
    <div className="filter-bar">
      <select
        value={filters.status ?? ''}
        onChange={e => onChange({ ...filters, status: (e.target.value as TodoStatus) || undefined })}
      >
        <option value="">All statuses</option>
        <option value="pending">Pending</option>
        <option value="in-progress">In Progress</option>
        <option value="completed">Completed</option>
      </select>

      <select
        value={filters.priority ?? ''}
        onChange={e => onChange({ ...filters, priority: (e.target.value as Priority) || undefined })}
      >
        <option value="">All priorities</option>
        <option value="high">High</option>
        <option value="medium">Medium</option>
        <option value="low">Low</option>
      </select>

      {(filters.status || filters.priority) && (
        <button className="btn-clear" onClick={() => onChange({})}>Clear filters</button>
      )}
    </div>
  );
}
