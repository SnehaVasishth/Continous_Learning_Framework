import { Todo, UpdateTodoPayload, TodoStatus } from '../types/todo';

interface Props {
  todo: Todo;
  onEdit: (todo: Todo) => void;
  onDelete: (id: number) => void;
  onStatusChange: (id: number, payload: UpdateTodoPayload) => void;
}

const priorityClass: Record<string, string> = {
  high: 'priority-high',
  medium: 'priority-medium',
  low: 'priority-low',
};

const statusLabel: Record<string, string> = {
  pending: 'Pending',
  'in-progress': 'In Progress',
  completed: 'Completed',
};

export function TodoItem({ todo, onEdit, onDelete, onStatusChange }: Props) {
  const nextStatus: Record<TodoStatus, TodoStatus> = {
    pending: 'in-progress',
    'in-progress': 'completed',
    completed: 'pending',
  };

  const formatDate = (d: string | null) =>
    d ? new Date(d).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : null;

  const important = Boolean(todo.is_important);

  return (
    <div className={`todo-item ${todo.status === 'completed' ? 'todo-completed' : ''} ${important ? 'todo-important' : ''}`}>
      <div className="todo-left">
        <button
          className={`status-badge status-${todo.status.replace('-', '')}`}
          title={`Click to mark as ${nextStatus[todo.status]}`}
          onClick={() => onStatusChange(todo.id, { status: nextStatus[todo.status] })}
        >
          {statusLabel[todo.status]}
        </button>
        <div className="todo-body">
          <div className="todo-title-row">
            <span className="todo-title">{todo.title}</span>
            {important && <span className="important-mark" title="Very important">★</span>}
          </div>
          {todo.description && <p className="todo-desc">{todo.description}</p>}
          <div className="todo-meta">
            <span className={`priority-badge ${priorityClass[todo.priority]}`}>{todo.priority}</span>
            {todo.category && <span className="category-badge">{todo.category}</span>}
            {todo.due_date && <span className="due-date">Due {formatDate(todo.due_date)}</span>}
          </div>
        </div>
      </div>
      <div className="todo-actions">
        <button
          className={`btn-icon btn-star ${important ? 'btn-star--active' : ''}`}
          title={important ? 'Remove important mark' : 'Mark as very important'}
          onClick={() => onStatusChange(todo.id, { is_important: !important })}
        >
          ★
        </button>
        <button className="btn-icon" title="Edit" onClick={() => onEdit(todo)}>✏️</button>
        <button className="btn-icon btn-danger" title="Delete" onClick={() => onDelete(todo.id)}>🗑️</button>
      </div>
    </div>
  );
}
