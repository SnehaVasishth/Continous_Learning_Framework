import { Todo, UpdateTodoPayload } from '../types/todo';
import { TodoItem } from './TodoItem';

interface Props {
  todos: Todo[];
  loading: boolean;
  onEdit: (todo: Todo) => void;
  onDelete: (id: number) => void;
  onStatusChange: (id: number, payload: UpdateTodoPayload) => void;
}

export function TodoList({ todos, loading, onEdit, onDelete, onStatusChange }: Props) {
  if (loading) {
    return <div className="empty-state">Loading…</div>;
  }

  if (todos.length === 0) {
    return <div className="empty-state">No todos yet. Add one above!</div>;
  }

  return (
    <div className="todo-list">
      {todos.map(todo => (
        <TodoItem
          key={todo.id}
          todo={todo}
          onEdit={onEdit}
          onDelete={onDelete}
          onStatusChange={onStatusChange}
        />
      ))}
    </div>
  );
}
