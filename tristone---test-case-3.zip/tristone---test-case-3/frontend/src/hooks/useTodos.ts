import { useState, useEffect, useCallback } from 'react';
import { Todo, CreateTodoPayload, UpdateTodoPayload, TodoFilters } from '../types/todo';
import { todoApi } from '../api/todoApi';

export function useTodos(filters: TodoFilters) {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await todoApi.fetchTodos(filters);
      setTodos(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load todos');
    } finally {
      setLoading(false);
    }
  }, [filters.status, filters.priority]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { load(); }, [load]);

  const create = async (payload: CreateTodoPayload) => {
    const created = await todoApi.createTodo(payload);
    setTodos(prev => [created, ...prev]);
    return created;
  };

  const update = async (id: number, payload: UpdateTodoPayload) => {
    const updated = await todoApi.updateTodo(id, payload);
    setTodos(prev => prev.map(t => (t.id === id ? updated : t)));
    return updated;
  };

  const remove = async (id: number) => {
    await todoApi.deleteTodo(id);
    setTodos(prev => prev.filter(t => t.id !== id));
  };

  return { todos, loading, error, create, update, remove, reload: load };
}
