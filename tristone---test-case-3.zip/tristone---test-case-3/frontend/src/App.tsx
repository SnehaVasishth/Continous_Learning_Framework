import { useState } from 'react';
import { Todo, TodoFilters, CreateTodoPayload } from './types/todo';
import { useTodos } from './hooks/useTodos';
import { FilterBar } from './components/FilterBar';
import { TodoList } from './components/TodoList';
import { TodoForm } from './components/TodoForm';

export default function App() {
  const [filters, setFilters] = useState<TodoFilters>({});
  const [showForm, setShowForm] = useState(false);
  const [editTodo, setEditTodo] = useState<Todo | null>(null);
  const { todos, loading, error, create, update, remove } = useTodos(filters);

  const handleSubmit = async (payload: CreateTodoPayload) => {
    if (editTodo) {
      await update(editTodo.id, payload);
    } else {
      await create(payload);
    }
    setShowForm(false);
    setEditTodo(null);
  };

  const handleEdit = (todo: Todo) => {
    setEditTodo(todo);
    setShowForm(true);
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditTodo(null);
  };

  const stats = {
    total: todos.length,
    completed: todos.filter(t => t.status === 'completed').length,
    pending: todos.filter(t => t.status === 'pending').length,
  };

  return (
    <div className="app">
      <header className="app-header">
        <div className="header-content">
          <h1>📝 To-Do App</h1>
          <button className="btn-primary" onClick={() => { setEditTodo(null); setShowForm(true); }}>
            + New Todo
          </button>
        </div>
        {todos.length > 0 && (
          <div className="stats">
            <span>{stats.total} total</span>
            <span className="stat-divider">·</span>
            <span className="stat-pending">{stats.pending} pending</span>
            <span className="stat-divider">·</span>
            <span className="stat-done">{stats.completed} completed</span>
          </div>
        )}
      </header>

      <main className="app-main">
        <FilterBar filters={filters} onChange={setFilters} />

        {error && <div className="error-banner">Error: {error}</div>}

        <TodoList
          todos={todos}
          loading={loading}
          onEdit={handleEdit}
          onDelete={remove}
          onStatusChange={(id, payload) => update(id, payload)}
        />
      </main>

      {showForm && (
        <TodoForm
          initial={editTodo}
          onSubmit={handleSubmit}
          onCancel={handleCancel}
        />
      )}
    </div>
  );
}
