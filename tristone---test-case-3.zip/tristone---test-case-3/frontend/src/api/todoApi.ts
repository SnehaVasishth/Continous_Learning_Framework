import { Todo, CreateTodoPayload, UpdateTodoPayload, TodoFilters } from '../types/todo';

const BASE = '/api/todos';

async function handleResponse<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const body = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(body.error ?? res.statusText);
  }
  if (res.status === 204) return undefined as unknown as T;
  return res.json() as Promise<T>;
}

export const todoApi = {
  fetchTodos(filters?: TodoFilters): Promise<Todo[]> {
    const params = new URLSearchParams();
    if (filters?.status) params.set('status', filters.status);
    if (filters?.priority) params.set('priority', filters.priority);
    const qs = params.toString() ? `?${params.toString()}` : '';
    return fetch(`${BASE}${qs}`).then(handleResponse<Todo[]>);
  },

  fetchTodo(id: number): Promise<Todo> {
    return fetch(`${BASE}/${id}`).then(handleResponse<Todo>);
  },

  createTodo(payload: CreateTodoPayload): Promise<Todo> {
    return fetch(BASE, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    }).then(handleResponse<Todo>);
  },

  updateTodo(id: number, payload: UpdateTodoPayload): Promise<Todo> {
    return fetch(`${BASE}/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    }).then(handleResponse<Todo>);
  },

  deleteTodo(id: number): Promise<void> {
    return fetch(`${BASE}/${id}`, { method: 'DELETE' }).then(handleResponse<void>);
  },
};
